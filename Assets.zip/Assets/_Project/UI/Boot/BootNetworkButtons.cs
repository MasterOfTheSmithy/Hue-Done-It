using Unity.Netcode;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace HueDoneIt.UI.Boot
{
    public sealed class BootNetworkButtons : MonoBehaviour
    {
        [SerializeField] private NetworkManager networkManager;

        public void StartHost()
        {
            Debug.Log("BootNetworkButtons.StartHost() clicked.");

            if (networkManager == null)
            {
                Debug.LogError("BootNetworkButtons: NetworkManager reference is missing.");
                return;
            }

            bool started = networkManager.StartHost();
            Debug.Log($"NetworkManager.StartHost() returned: {started}");

            if (!started)
            {
                Debug.LogError("BootNetworkButtons: Host failed to start.");
                return;
            }

            if (!networkManager.NetworkConfig.EnableSceneManagement)
            {
                Debug.LogWarning("BootNetworkButtons: Enable Scene Management is off. Loading Gameplay locally only.");
                SceneManager.LoadScene("Gameplay_Undertint", LoadSceneMode.Single);
                return;
            }

            networkManager.SceneManager.LoadScene("Gameplay_Undertint", LoadSceneMode.Single);
        }

        public void StartClient()
        {
            Debug.Log("BootNetworkButtons.StartClient() clicked.");

            if (networkManager == null)
            {
                Debug.LogError("BootNetworkButtons: NetworkManager reference is missing.");
                return;
            }

            bool started = networkManager.StartClient();
            Debug.Log($"NetworkManager.StartClient() returned: {started}");
        }

        public void Shutdown()
        {
            Debug.Log("BootNetworkButtons.Shutdown() clicked.");

            if (networkManager == null)
            {
                Debug.LogError("BootNetworkButtons: NetworkManager reference is missing.");
                return;
            }

            networkManager.Shutdown();
            Debug.Log("NetworkManager shutdown complete.");
        }
    }
}